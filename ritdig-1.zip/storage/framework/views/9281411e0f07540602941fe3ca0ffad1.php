<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <style>
        p {
            font-size: 12px;
        }

        .signature {
            font-style: italic;
        }
    </style>
</head>
<body>
<div>
    <p>My Name is:<?php echo e($mailData['name']); ?>,</p>
    <p> My Email is:<?php echo e($mailData['email']); ?>,</p>
    <p>My Message is:<?php echo e($mailData['message']); ?>,</p>


</div>
</body>
</html><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\mail.blade.php ENDPATH**/ ?>