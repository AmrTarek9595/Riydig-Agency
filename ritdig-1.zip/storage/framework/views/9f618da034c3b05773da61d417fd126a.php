
 <!-- Preloader -->
 <?php $__env->startSection('route'); ?>
   <style>

        /**
                                        //////////        
        */


   </style>
        <!-- Hero Slider start -->
        <section class="hero-banner-1">
            <div class="content text-center w-100">
                <!-- <h1 class="fs-155 fw-7 text-shadow color-white ls-0 mb-0 lh-100 headline_1">Agency</h1>

                <h1 class="fs-155 fw-7 text-shadow color-white ls-0 mb-0 lh-100 headline" style="margin-top: 70px;font-size: 90px;">RIYDIG</h1> -->
                <div class="container-fluid">
                <div class="row">
                    <div class="content">
                        <div class="text-reveal mb-32">
                            <!-- <span class="random-word h-91 color-sec">Web Design:</span> -->
                            <!-- <h1 "><br></h1> -->

                            <div class="hero-h1"><h1 style="color: aliceblue;font-family: 'Givonic-bold';">DIG INTO: </h1>
                                <span style="color: wheat;" class="random-word h-91 color-primary"></span>
                            </div>
                        </div>
                        <p class="medium-gray mb-32">
                        </p>
                        <a href="/contact" class="cus-btn dark">Let's Dig Deeper</a>
                    </div>
                </div>
          
            </div>
                
            </div>
        </section>
        <!-- Hero Slider end -->
        <!-- services start -->
        <!-- <section class="services-1 about-1" data-sal="flip-left" data-sal-duration="1100" data-sal-delay="300" data-sal-easing="ease-in-out">
            <div class="heading-1 left">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase lh-100 mb-0">Services</h1>
            </div>
            <div class="container">
              
                <div class="row mt-48">
                    <div class="col-lg-6">
                        <img class="show service-img s-1" src="assets/media/service/2150829239.jpg" alt="">
                        <img class="service-img s-2" src="assets/media/service/2150063164.jpg" alt="">
                        <img class="service-img s-3" src="assets/media/service/2150829239.jpg" alt="">
                        <img class="service-img s-4" src="assets/media/service/2150063164.jpg" alt="">
                        <img class="service-img s-5" src="assets/media/service/2150829239.jpg" alt="">
                        <img class="service-img s-6" src="assets/media/service/2150063164.jpg" alt="">
                    </div>
                    <div class="col-lg-6 mt-48">
                        <div class="service-box s-1 show" data-count="1" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-quint">
                            <h2 class="fs-40 fw-4">
                                <span class="d-inline-block icon"><i class="fal fa-plus plus"></i> <i class="fal fa-times minus"></i></span> Brand Strategy and Identity:
                            </h2>
                            <p class="ms-5 ps-4">Our branding strategy experts work with you to develop a<br>
                                comprehensive
                                strategy and identity that aligns with your<br> goals and speaks to your audience.</p>
                        </div>
                        <br>
                        <div class="service-box s-2" data-count="2" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-quint">
                            <h2 class="fs-40 fw-4">
                                <span class="d-inline-block icon"><i class="fal fa-plus plus"></i> <i class="fal fa-times minus"></i></span>
                                Web Design and Development:
                            </h2>
                            <p class="ms-5 ps-4">Our branding strategy experts work with you to develop a<br>
                                comprehensive
                                strategy and identity that aligns with your<br> goals and speaks to your audience.</p>
                        </div>
                        <br>
                        <div class="service-box s-3" data-count="3" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-quint">
                            <h2 class="fs-40 fw-4">
                                <span class="d-inline-block icon"><i class="fal fa-plus plus"></i> <i class="fal fa-times minus"></i></span>
                                Social Media Management:
                            </h2>
                            <p class="ms-5 ps-4">Our branding strategy experts work with you to develop a<br>
                                comprehensive
                                strategy and identity that aligns with your<br> goals and speaks to your audience.</p>
                        </div>
                        <br>
                        <div class="service-box s-4" data-count="4" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-quint">
                            <h2 class="fs-40 fw-4">
                                <span class="d-inline-block icon"><i class="fal fa-plus plus"></i> <i class="fal fa-times minus"></i></span>
                                Search Engine Optimization (SEO):
                            </h2>
                            <p class="ms-5 ps-4">Our branding strategy experts work with you to develop a<br>
                                comprehensive
                                strategy and identity that aligns with your<br> goals and speaks to your audience.</p>
                        </div>
                        <br>
                        <div class="service-box s-5" data-count="5" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-quint">
                            <h2 class="fs-40 fw-4">
                                <span class="d-inline-block icon"><i class="fal fa-plus plus"></i> <i class="fal fa-times minus"></i></span>
                                Content Creation and Marketing:
                            </h2>
                            <p class="ms-5 ps-4">Our branding strategy experts work with you to develop a<br>
                                comprehensive
                                strategy and identity that aligns with your<br> goals and speaks to your audience.</p>
                        </div>
                        <br>
                        <div class="service-box s-6" data-count="6" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-quint">
                            <h2 class="fs-40 fw-4">
                                <span class="d-inline-block icon">
                                    <i class="fal fa-plus plus"></i> 
                                    <i class="fal fa-times minus"></i>
                                </span>
                                Brand Identity:
                            </h2>
                            <p class="ms-5 ps-4">Our branding strategy experts work with you to develop a<br>
                                comprehensive
                                strategy and identity that aligns with your<br> goals and speaks to your audience.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- Services end -->
<!-- Services Start -->
<section class="team-2 about-1 team-section" data-sal="flip-down" data-sal-duration="800" data-sal-delay="300" data-sal-easing="ease-in-out" style="    position: relative;">
            <div class="heading-1 right">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase lh-100 bg-img">Services
                </h1>
            </div>
            <div class="container">

                <div class="clearfix"></div>
                <div class="row mt-100">
                    <div class="col-lg-8 image-wraper ">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="img-box member-<?php echo $index + 1; ?>" style="<?php echo $index == 0 ? 'display: block;' : 'display: none;'; ?>">
                           
                           
                            <img class="team-img shadow" src="/images/<?php echo e($datas->image_name); ?>" alt="">
                            <h2 class="fs-53 mb-0 mt-4 color-dark-2"><?php echo e($datas->title_en); ?></h2>
                            <div class="row">
                                <div class="col-lg-6"> 
                                        <div class="button-wrapper primary">  
                                                    <a href="/service/<?php echo e($datas->id); ?>" class="button" type="button">
                                                        Discover More...
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>

                                      
                                </div> 
                                <div class="col-lg-6">
                                        <div class="button-wrapper secondary">  
                                                    <a href="/services" class="button" type="button">
                                                        All Services
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>
                                </div>
                            </div>
                          
                            
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  

                        <!-- <div class="img-box member-2" style="display: none;">
                       
                            <img class="team-img shadow" src="assets/media/service/2150829239.jpg" alt="">
                            <h2 class="fs-53 mb-0 mt-4 color-dark-2">(SEO) &amp; Content Creation</h2>
                            <div class="row">
                                <div class="col-lg-6"> 
                                        <div class="button-wrapper primary">  
                                                    <a href="/service/SEO" class="button" type="button">
                                                        Discover More...
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>

                                      
                                </div>
                                <div class="col-lg-6">
                                        <div class="button-wrapper secondary">  
                                                    <a href="/services" class="button" type="button">
                                                        All Services
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <div class="img-box member-3" style="display: none;">
                          
                            <img class="team-img shadow" src="assets/media/service/2150829239.jpg" alt="">
                            <h2 class="fs-53 mb-0 mt-4 color-dark-2">OOH</h2>
                            <div class="row">
                                <div class="col-lg-6"> 
                                        <div class="button-wrapper primary">  
                                                    <a href="/service/OOH" class="button" type="button">
                                                        Discover More...
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>

                                      
                                </div>
                                <div class="col-lg-6">
                                        <div class="button-wrapper secondary">  
                                                    <a href="/services" class="button" type="button">
                                                        All Services
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <div class="img-box member-4" style="display: none;">
                           
                            <img class="team-img shadow" src="assets/media/crew/image-5.png" alt="">
                            <h2 class="fs-53 mb-0 mt-4 color-dark-2">Brand Stratgy</h2>
                            <div class="row">
                                <div class="col-lg-6"> 
                                        <div class="button-wrapper primary">  
                                                    <a href="/service/Brand_Strategy" class="button" type="button">
                                                        Discover More...
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>

                                      
                                </div>
                                <div class="col-lg-6">
                                        <div class="button-wrapper secondary">  
                                                    <a href="/services"  class="button" type="button">
                                                        All Services
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <div class="img-box member-5" style="display: none;">
                           
                            <img class="team-img shadow" src="assets/media/service/2150829239.jpg" alt="">
                            <h2 class="fs-53 mb-0 mt-4 color-dark-2">Web Applications</h2>
                            <div class="row">
                                <div class="col-lg-6"> 
                                        <div class="button-wrapper primary">  
                                                    <a href="/service/Website" class="button" type="button">
                                                        Discover More...
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>

                                      
                                </div>
                                <div class="col-lg-6">
                                        <div class="button-wrapper secondary">  
                                                    <a href="/services" class="button" type="button">
                                                        All Services
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <div class="img-box member-6" style="display: none;">
                           
                            <img class="team-img shadow" src="assets/media/service/2150829239.jpg" alt="">
                            <h2 class="fs-53 mb-0 mt-4 color-dark-2">Mobile Applications</h2>
                            <div class="row">
                                <div class="col-lg-6"> 
                                        <div class="button-wrapper primary">  
                                                    <a href="/service/Mobile_App" class="button" type="button">
                                                        Discover More...
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>

                                      
                                </div>
                                <div class="col-lg-6">
                                        <div class="button-wrapper secondary">  
                                                    <a href="/services" class="button" type="button">
                                                        All Services
                                                        <span class="button-inner-wrapper">    
                                                        <span class="button-inner"></span>
                                                        </span>
                                                    </a>
                                        </div>
                                </div>
                            </div>
                        </div> -->
                    </div>


                    <div class="col-lg-4">
                        <ul class="unstyled members">

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$datas2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                          
                            <li class="single member-1 <?php echo e($index == 0 ? 'show' : ''); ?>" data-count="<?php echo e($index + 1); ?>">
                                <div class="content">
                                    
                                      
                                    <h3 class="fs-69 mb-0 lh-100"><?php echo e($datas2->title_en); ?></h3>



                                    <p><?php echo e($datas2->quotation_en); ?> 
                                    </p>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            


                        </ul>
                    </div>
                </div>
            </div>
        </section>
<!-- Services end -->

        <!-- clients start -->
     
        <section class="reviews-1 review-section" data-sal="slide-up" data-sal-duration="800" data-sal-delay="100" data-sal-easing="ease-in-out">
            <div class="heading-1 left">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase lh-100 bg-img">Clients</h1>
            </div>
            <div class="container" style="    margin-top: 100px;max-width: 100%;text-align: center;">
                <!-- <h4 class="glitter-text  text-center">Our Team Worked with these Valued Clients</h4> -->
                <h2 class="our-team-clients">Our Team Worked with these Valued Clients</h2>
                <div class="logo-slider">
                    <div class="logo-slide-track">
                    <div class="slide">
                        <img src="/assets/media/CL/1_Trivium.png" alt="Trivium" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/2_inm.png" alt="inm" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/3_INMA.png" alt="INMA" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/4_Trend_Aqar.png" alt="Trend Aqar" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/5_Makan.png" alt="Makan" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/6_Genena_Mall.png" alt="Genena Mall" />
                    </div>
                    <div class="slide">
                        <img src="/assets/media/CL/7_Landor.png" alt="Landor" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/8_Las.png" alt="Las Vegan" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/9_Chilis.png" alt="Chilis" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/10_Tseppas.png" alt="Tseppas" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/11_President.png" alt="President" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/12_BMW.png" alt="BMW" />
                    </div>     
                    <div class="slide">
                        <img src="/assets/media/CL/13_Land.png" alt="Land Rover" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/14_JAG.png" alt="JAGUAR" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/15_Ford.png" alt="Ford" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/16_Levon.png" alt="Levon" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/17_Beko.png" alt="Beko" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/18_Atlantic.png" alt="Atlantic" />
                    </div>     <div class="slide">
                        <img src="/assets/media/CL/19_Spotify.png" alt="Spotify" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/20_Etisalat.png" alt="Etisalat" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/21_Oredo.png" alt="Oredo" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/22_EU.png" alt="EU" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/23_Governrate.png" alt="Governrate" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/24_Genena.png" alt="Genena" />
                    </div>
                    <div class="slide">
                        <img src="/assets/media/CL/25_Plan.png" alt="Plan" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/26_Verfifed_Agency_Hexagonal.png" alt="Verfifed Agency Hexagonal"/>
                    </div>
                     <!-- Duplicate slides to create a continuous loop --> 
                     <!-- <div class="slide">
                        <img src="/assets/media/CL/1_Trivium.png" alt="Trivium" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/2_inm.png" alt="inm" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/3_INMA.png" alt="INMA" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/4_Trend_Aqar.png" alt="Trend Aqar" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/5_Makan.png" alt="Makan" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/6_Genena_Mall.png" alt="Genena Mall" />
                    </div>
                    <div class="slide">
                        <img src="/assets/media/CL/7_Landor.png" alt="Landor" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/8_Las.png" alt="Las Vegan" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/9_Chilis.png" alt="Chilis" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/10_Tseppas.png" alt="Tseppas" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/11_President.png" alt="President" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/12_BMW.png" alt="BMW" />
                    </div>     
                    <div class="slide">
                        <img src="/assets/media/CL/13_Land.png" alt="Land Rover" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/14_JAG.png" alt="JAGUAR" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/15_Ford.png" alt="Ford" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/16_Levon.png" alt="Levon" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/17_Beko.png" alt="Beko" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/18_Atlantic.png" alt="Atlantic" />
                    </div>     <div class="slide">
                        <img src="/assets/media/CL/19_Spotify.png" alt="Spotify" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/20_Etisalat.png" alt="Etisalat" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/21_Oredo.png" alt="Oredo" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/22_EU.png" alt="EU" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/23_Governrate.png" alt="Governrate" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/24_Genena.png" alt="Genena" />
                    </div>
                    <div class="slide">
                        <img src="/assets/media/CL/25_Plan.png" alt="Plan" />
                    </div> 
                    <div class="slide">
                        <img src="/assets/media/CL/26_Verfifed_Agency_Hexagonal.png" alt="Verfifed Agency Hexagonal"/>
                    </div> -->


                </div>
            </div>


                        </div>
          
        </section>
        <!-- clients end -->  





        <!-- About start -->
        <section class="about-1" data-sal="flip-down" data-sal-duration="800" data-sal-delay="300" data-sal-easing="ease-in-out" style="margin-top:15px">
            <div class="heading-1 right" data-sal="flip-down" data-sal-duration="800" data-sal-delay="300" data-sal-easing="ease-in-out">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase mb-0 lh-100 bg-img">About us
                </h1>   
            </div>
            <div class="container">
                
                <div class="clearfix"></div>
                <div class="row mt-48">
                    <div class="col-lg-6">
                        <img src="assets/media/about/2150976030.jpg" alt="" style="height:80%">
                    </div>
                    <div class="col-lg-6">
                        <p class="fs-53 color-dark-2 ls-0">Ideology</p>
                        <p class="ps-3">We are a marketing powerhouse, fostering valued partnerships across Egypt, Saudi Arabia, and the United Arab Emirates.<br>
                        
                        </p>

                        <p class="ps-3">  Driven by innovation, we unite regional insights with a global outlook to craft strategies that resonate with diverse audiences and drive measurable impact.</p>
                        <div class="steps mt-100">
                            <div class="title fs-155 fw-7 text-uppercase">Steps</div>
                            <div class="row mb-5" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-out">
                                <div class="col-lg-3 col-sm-2 counting">
                                    <strong class="fs-91 color-dark-2 text-uppercase lh-100 position-relative z-2">01</strong>
                                </div>
                                <div class="col-lg-9 col-sm-10">
                                    <p><strong class="color-dark-2">Discover:</strong> We dig deep into the essence of your brand, <br>revealing unique strengths that set you apart.
                                    </p>
                                </div>
                            </div>
                            <div class="row mb-5" data-sal="slide-left" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-out">
                                <div class="col-lg-3 col-sm-2 counting">
                                    <strong class="fs-53 color-dark-2 text-uppercase lh-100 position-relative z-2">02</strong>
                                </div>
                                <div class="col-lg-9 col-sm-10">
                                    <p><strong class="color-dark-2">Create:</strong> Build Brands’ authentic voice and bespoke strategies,<br> fueled by insights and creative minds.
                                    </p>
                                </div>
                            </div>
                            <div class="row mb-5" data-sal="slide-right" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-out">
                                <div class="col-lg-3 col-sm-2 counting">
                                    <strong class="fs-40 color-dark-2 text-uppercase lh-100 position-relative z-2">03</strong>
                                </div>
                                <div class="col-lg-9 col-sm-10">
                                    <p><strong class="color-dark-2">Launch:</strong> implement strategy with precision, ensuring a smooth and impactful entry into the market.
                                    </p>
                                </div>
                            </div>
                            <div class="row" data-sal="slide-left" data-sal-duration="2000" data-sal-delay="100" data-sal-easing="ease-in-out">
                                <div class="col-lg-3 col-sm-2 counting">
                                    <strong class="fs-31 color-dark-2 text-uppercase lh-100 position-relative z-2">04</strong>
                                </div>
                                <div class="col-lg-9 col-sm-10">
                                    <p><strong class="color-dark-2">Evolve:</strong>  Continuously optimize for results, ensuring your brand stands out in a dynamic market.

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

 
        <!-- Portfolio start -->
        <!-- <section class="portfolio-1" data-sal="slide-up" data-sal-duration="800" data-sal-delay="100" data-sal-easing="ease-in-out">
            <div class="heading-1 right">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase mb-0  lh-100 bg-img">Portfolio
                </h1>   
            </div>
            <div class="container">
                <div class="clearfix"></div>
                <div class="image-wraper mt-48">
                    <img src="assets/media/portfolio/image-3.png" alt="" class="img-box shadow lg zi-1">
                    <img src="assets/media/portfolio/image-2.png" alt="" class="img-box shadow sm zi-2">
                    <img src="assets/media/portfolio/image-1.png" alt="" class="img-box shadow sm zi-3">
                    <img src="assets/media/portfolio/image.png" alt="" class="img-box shadow sm zi-4">
                </div>
                <div class="image-wraper">
                    <img src="assets/media/portfolio/image-6.png" alt="" class="img-box shadow lg zi-1">
                    <img src="assets/media/portfolio/image-5.png" alt="" class="img-box shadow md zi-2">
                    <img src="assets/media/portfolio/image-4.png" alt="" class="img-box shadow sm zi-3">
                </div>
                <div class="image-wraper">
                    <img src="assets/media/portfolio/image-10.png" alt="" class="img-box shadow lg zi-1">
                    <img src="assets/media/portfolio/image-9.png" alt="" class="img-box shadow sm zi-2">
                    <img src="assets/media/portfolio/image-8.png" alt="" class="img-box shadow sm zi-3">
                    <img src="assets/media/portfolio/image-7.png" alt="" class="img-box shadow sm zi-4">
                </div>
            </div>
            <div class="text-center mt-5">
                <a href="portfolio.html" class="cus-btn light">Discover More</a>
            </div>
        </section> -->
        <!-- Portfolio end -->



        <!-- Project start -->
        <section class="reviews-1 review-section" data-sal="slide-up" data-sal-duration="800" data-sal-delay="100" data-sal-easing="ease-in-out">
            <div class="heading-1 left">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase lh-100 bg-img">Projects
                </h1>
            </div>
            <div class="container" s>
                <h2 class="vertitle-title">GLOBAL</h2>
                <div class="row mt-64">
                    <div class="col-lg-10 offset-lg-2">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="row">
                                <div class="row">
                                    <div class="col-lg-6 offset-lg-6 col-sm-6">
                                        <div class="box client-1 show shadow cus-margin mb-5" data-count="1">
                                        <a href="/portfolio">All Projects</a>
                                        </div>
                                    </div>
                                </div>
                                    
                                </div>

                                <div class="content">
                                    <div class="client-1 show">
                                        <p></p>
                                    </div>
                                 
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="row mb-4">

                                <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <div class="col-lg-6 col-sm-6">
                                        <div class="box client-2 shadow" data-count="<?php echo e($index+1); ?>">
                                        <?php if(str_contains($data, ' ')): ?>
                                       
                                        <a href="portfolio?type=<?php echo e(str_replace(' ', '_', $data)); ?>"><?php echo e($data); ?></a>
                                        <?php else: ?>
                                        <a href="portfolio?type=<?php echo e($data); ?>"><?php echo e($data); ?></a>

                                        <?php endif; ?>
                                      
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                                    <!-- <div class="col-lg-6 col-sm-6">
                                        <div class="box client-3 shadow" data-count="3">
                                        <a href="/portfolio?type=Mobile_Apps">Mobile Application</a>
                                        </div>
                                    </div> -->
                                </div>
                                <!-- <div class="row">
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="box client-4 shadow" data-count="4">
                                         <a>Media Buying</a>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="box client-5 shadow" data-count="5">
                                            <a>SEO/SEM</a>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                            <!-- <div class="col-lg-2 col-sm-6">
                                        <div class="box client-1 shadow cus-margin" data-count="6">
                                        <a>OOH</a>
                                        </div>
                            </div> -->

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- project end -->     
        <section class="blog-1 mb-100 mt-64 sal-animate" data-sal="slide-up" data-sal-duration="800" data-sal-delay="100" data-sal-easing="ease-in-out">
            <div class="heading-1 right">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase lh-100 mb-0">News</h1>
            </div>
            <div class="container">
                <div class="clearfix"></div>
                <div class="row mt-100">
                    <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <a href="/singleBlog/<?php echo e($data->id); ?>" class="box">
                            <div class="img-box">
                                <img class="br-25 shadow w-100" alt="" src="/images/blogs/<?php echo e($data->image_en); ?>">
                               
                                
                            </div>
                            <div class="content mt-64">
                                <h2 class="color-dark-2 fs-31  mb-2"><?php echo e($data->title_en); ?></h2>
                                <p><?php echo e($data->quotation_en); ?></p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
      
                </div>
            </div>
        </section>
        <?php $__env->stopSection(); ?>

<style lang="scss">
    .reviews-1 .box a{
        font-size:2.5em;color:#262626;font-weight: 750;
    }
    


.button-wrapper {
  filter: drop-shadow(0 8px 8px var(--shadow-color));
}
.button-wrapper.primary {
  --shadow-color: rgb(36 25 95 / .8);
}
.button-wrapper.secondary {
  --shadow-color: rgb(255 255 255 / .4);
}

.button {
  position: relative;
  padding: 12px 40px;
  min-width: 12em;
  clip-path: polygon(14px 0, calc(100% - 14px) 0, 100% 50%, calc(100% - 14px) 100%, 14px 100%, 0 50%);
  text-align: center;
  font-family: "IBM Plex Mono", monospace;
  color: #fff;
  transition-property: transform;
  transition-duration: 0.4s;
  transition-timing-function: cubic-bezier(0.55, 1, 0.15, 1);
}
.button-wrapper.primary .button {
  background-image: linear-gradient(to bottom, #29224d, #776cc9);
}
.button-wrapper.primary .button:hover {
  background-image: linear-gradient(to bottom, #8a8894, #c8c7ca);
}
.button-wrapper.secondary .button {
  background-image: linear-gradient(to bottom, #8a8894, #c8c7ca);
}
.button-wrapper.secondary .button:hover {
    background-image: linear-gradient(to bottom, #29224d, #776cc9);
}
.button:active {
  transform: scale(0.94);
}

.button-inner-wrapper {
  position: absolute;
  z-index: -1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  filter: blur(2px);
}

.button-inner {
  content: "";
  position: absolute;
  z-index: -1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  clip-path: polygon(14px 4px, calc(100% - 14px) 4px, calc(100% - 1px) 50%, calc(100% - 14px) calc(100% - 4px), 14px calc(100% - 4px), 1px 50%);
}
.button-wrapper.primary .button-inner {
  background-image: linear-gradient(to bottom, #080616, #3e3861);
}
.button-wrapper.secondary .button-inner {
  background-image: linear-gradient(to right, #67666e, #0f0d21);
}

</style>
    

    
<?php echo $__env->make('layout.en.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\index.blade.php ENDPATH**/ ?>