
 <!-- Preloader -->
 <?php $__env->startSection('route'); ?>
 <section class="page-title">
            <div class="container">
                <ul class="breadcrumb unstyled">
                    <li><a href="/">Home</a></li>
                    <li><a href="/services">Services</a></li>
                    <li class="active"><a href="/service/social_media">Social Media</a></li>
                </ul>
                <h1 class="mb-0 color-dark-2">Social Media</h1>
                <h3>Detail</h3>
            </div>
</section>


<section class="services-detail mt-100 mb-48 container">
            <div class="row">
                <div class="col-lg-3">
                    <img class="" alt="" src="/assets/media/service/s3-1.png">
                </div>
                <div class="col-lg-9">
                    <h1 class="fs-53 fw-7 color-dark-2">Social Media Management</h1>
                    <div class="row">
                        <div class="col-lg-7">
                            <p class="ps-5">Social media management involves creating, scheduling, and analyzing content
                                on
                                social media platforms to engage with your target audience, increase brand awareness,
                                and
                                promote your business. It involves managing social media accounts, creating and sharing
                                content,
                                engaging with users, and analyzing social media metrics to track the success of your
                                campaigns.
                            </p>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-lg-6 offset-lg-6">
                            <h2 class="fs-53 color-dark-2">Benefits</h2>
                            <div class="row">
                                <div class="col-lg-6 col-sm-6">
                                    <ul class="unstyled points">
                                        <li class="fs-24">Content Strategy</li>
                                        <li class="fs-24">Engagement</li>
                                        <li class="fs-24">Analytics</li>
                                        <li class="fs-24">Collaboration</li>
                                    </ul>
                                </div>
                                <div class="col-lg-6 col-sm-6">
                                    <ul class="unstyled points">
                                        <li class="fs-24">Content Strategy</li>
                                        <li class="fs-24">Engagement</li>
                                        <li class="fs-24">Analytics</li>
                                        <li class="fs-24">Collaboration</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
</section>




<section class="portfolio-1 mb-5 sal-animate" data-sal="slide-up" data-sal-duration="800" data-sal-delay="100" data-sal-easing="ease-in-out">
            <div class="heading-1 right">
                <h1 class="color-dark-2 fs-91 fw-7 text-uppercase mb-0  lh-100 bg-img">Work
                </h1>
            </div>
            <div class="container">
                <div class="clearfix"></div>
                <div class="image-wraper mt-48">
                    <img src="/assets/media/portfolio/image-3.png" alt="" class="img-box shadow lg zi-1">
                    <img src="/assets/media/portfolio/image-2.png" alt="" class="img-box shadow sm zi-2">
                    <img src="/assets/media/portfolio/image-1.png" alt="" class="img-box shadow sm zi-3">
                    <img src="/assets/media/portfolio/image.png" alt="" class="img-box shadow sm zi-4">
                </div>
            </div>
</section>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout.en.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\single_services\6_Marketing_Strategy.blade.php ENDPATH**/ ?>