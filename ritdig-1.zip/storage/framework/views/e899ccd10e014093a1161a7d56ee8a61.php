

<?php $__env->startSection('content'); ?>
<div class="container" style="top: 50%;position: absolute;left: 30%;">
    <img src="/assets/media/logo_Black.png" style="width: 100%;max-height: 100%;"/>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\auth\mainPage.blade.php ENDPATH**/ ?>