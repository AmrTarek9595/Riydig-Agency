

<?php $__env->startSection('content'); ?>
<div class="app-main__outer">
<div class="app-main__inner">
<div class="app-page-title">
<div class="page-title-wrapper">
<div class="page-title-heading">
<div class="page-title-icon">
<i class="pe-7s-drawer icon-gradient bg-happy-itmeo"></i>
</div>
<div>Leads From Contact US
<div class="page-title-subheading">Check new Messages</div>
</div>
</div>

</div>
</div> <div class="row">





<div class="col-lg-12">
<div class="main-card mb-3 card">
<div class="card-body">
<h5 class="card-title">Table responsive</h5>
<div class="table-responsive">
<table class="mb-0 table">
    
<?php if(Session::has('success')): ?>
                    <div class="alert alert-primary" role="alert">
                    <?php echo e(Session::get('success')); ?>

                    </div>
                    
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('error')); ?>

                    </div>
    <?php endif; ?>
<thead>
<tr>
<th>#</th>
<th>Name</th>
<th>Email</th>
<th>Message</th>
<th>Response</th>
<th>Action</th>
</tr>
</thead>
<tbody>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <th scope="row"><?php echo e($index+1); ?></th>
    
    <td><?php echo e($datas->name); ?></td>
    <td><?php echo e($datas->email); ?></td>
    <td><?php echo e($datas->message); ?></td>
    <?php if($datas->status==0): ?>
    <td>Not Answerd Yet</td>
    <?php else: ?>
    <td>Answered</td>
    <?php endif; ?>
    <td>
        <?php if($datas->status == 0): ?>
    <form action="/updateContact/<?php echo e($datas->id); ?>" method="POST" enctype= multipart/form-data>
    <?php echo csrf_field(); ?>
    <button class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success"><i class="lnr-license btn-icon-wrapper"> </i>Update Response</button>
    </form>
    <?php endif; ?>
</td>

</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
</table>
</div>
</div>
</div>
</div>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\auth\contact_us\contact_us.blade.php ENDPATH**/ ?>