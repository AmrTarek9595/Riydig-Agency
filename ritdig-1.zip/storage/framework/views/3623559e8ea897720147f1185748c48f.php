
 <!-- Preloader -->
 <?php $__env->startSection('route'); ?>
     
    <section class="page-title">
            <div class="container">
                <ul class="breadcrumb unstyled">
                    <li><a href="/">Home</a></li>
                    <li><a href="!#">Blogs</a></li>
                    <li><a class="active" href=!#"><?php echo e($data->title_en); ?></a></li>
                </ul>
                <h1 class="mb-0 color-dark-2"><?php echo e($data->title_en); ?></h1>
                <h3>Detail</h3>
            </div>
    </section>

    <section class="blog-detail mb-48 sal-animate" data-sal="slide-up" data-sal-duration="800" data-sal-delay="100" data-sal-easing="ease-in-out">

            <div class="container">
            
                <div class="row mt-64">
                    <div class="col-lg-4 pe-0">
                        <img src="/images/blogs/<?php echo e($data->image_en); ?>" alt="<?php echo e($data->title_en); ?>" style="border-radius: 70px;    max-height: 360px;">
                    </div>
                    <div class="col-lg-8">
                        <h1 class="fs-69" alt="<?php echo e($data->title_en); ?>" tag="<?php echo e($data->title_en); ?>" ><?php echo e($data->title_en); ?></h1>
                        <div class="author-block">
                            <!-- <span class="shadow fs-24 br-15 date bg-white color-primary">12 DEC 2023</span> -->
                            <img class="author shadow br-15" alt="" src="assets/media/blogs/listing/author-1.png">

                        </div>
                        <p class="mt-100" alt="<?php echo e($data->title_en); ?>"><?php echo $data->quotation_en; ?></p>
                    </div>
                </div>
                <h2 class="fs-91 text-center color-dark" alt="<?php echo e($data->title_en); ?>" tag="<?php echo e($data->title_en); ?>"><span class="fs-155">"</span><?php echo e($data->title_en); ?><span class="fs-155">"</span></h2>
                <div class="row" style="justify-content:center">
                <div class="col-6">
                <p><?php echo $data->body_en; ?></p>

                </div>
                <ul>
                    <?php $__currentLoopData = $keyword; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                    <li style="display:none;">
                        <a href="https://riydig.agency" rel="tag" ><?php echo e($keyw->keyword); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                </div>
         
            </div>
        </section>
 <?php $__env->stopSection(); ?>

    

<?php echo $__env->make('layout.en.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\single_blog.blade.php ENDPATH**/ ?>