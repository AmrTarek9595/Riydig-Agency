

<?php $__env->startSection('content'); ?>
<div class="app-main__outer">
<div class="app-main__inner">
<div class="app-page-title">
<div class="page-title-wrapper">
<div class="page-title-heading">
<div class="page-title-icon">
<i class="pe-7s-graph text-success"></i>
</div>
<div>Display Projects
<div class="page-title-subheading"></div>
</div>
</div>

</div>
</div> <div class="row">





<div class="col-lg-12">
<div class="main-card mb-3">
<div class="card-body">
<h5 class="card-title"></h5>
<div class="table-responsive">
    
<?php if(Session::has('success')): ?>
                    <div class="alert alert-primary" role="alert">
                    <?php echo e(Session::get('success')); ?>

                    </div>
                    
    <?php endif; ?>
<table class="mb-0 table">
<thead>
<tr>
<th>#</th>
<th>Title</th>
<th>Type</th>
<th>Image</th>
<th>Update</th>
<th>Delete</th>

</tr>
</thead>
<tbody>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr>
<th scope="row"><?php echo e($index+1); ?></th>
<td><?php echo e($datas->project_title); ?></td>
<td><?php echo e($datas->type); ?></td>
<td><img src="/images/projects/<?php echo e($datas->image_name); ?>" style="width:100px;height:100px;"></td>





<td><a href="/updateProject/<?php echo e($datas->id); ?>" class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-success"><i class="lnr-license btn-icon-wrapper"> </i>Update</a></td>

<td>
    <form action="/deleteProject/<?php echo e($datas->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
    <button onclick="return confirmDelete('Are you sure you want to delete this post?')" class="mb-2 mr-2 btn-hover-shine btn btn-shadow btn-danger"><i class="lnr-lighter btn-icon-wrapper"> </i>Delete</button></td>

    </form>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>


</div>
</div>
</div>
<div class="col-lg-12">

<div class="main-card mb-3 card">
<div class="card-body">

<?php if($data->hasPages()): ?>
    <ul class="pagination">
        
        <?php if($data->onFirstPage()): ?>
            <li class="page-item disabled"><span class="page-link">Previous</span></li> 

        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($data->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?> 


        
        <?php if($data->hasMorePages()): ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($data->nextPageUrl()); ?>">Next</a></li>
        <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Next</span></li>
        <?php endif; ?> 

    </ul>
<?php endif; ?>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
    function confirmDelete(message) {
        return confirm(message);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64_new\www\ritdig\resources\views\auth\projects\DisplayProjects.blade.php ENDPATH**/ ?>