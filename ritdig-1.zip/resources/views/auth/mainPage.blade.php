@extends('layouts.app')

@section('content')
<div class="container" style="top: 50%;position: absolute;left: 30%;">
    <img src="/assets/media/logo_Black.png" style="width: 100%;max-height: 100%;"/>
</div>
@endsection
