@extends('layout.en.layout')
 <!-- Preloader -->
 @section('route')
      <!-- Title Banner -->
      <section class="page-title">
            <div class="container">
                <ul class="breadcrumb unstyled">
                    <li><a href="/">Home</a></li>
                    <li class="active"><a href="/services">Services</a></li>
                </ul>
                <h1 class="mb-0 color-dark-2">Services</h1>
                <style>
                    
                    .colorful-text {
                     text-align: center;
                     text-transform: uppercase;
                     font-size: 300px;
                     -webkit-text-stroke: 0.1px #D5D5D5;
                     -webkit-text-fill-color: red;
                     font-weight: 750;
                     font-family: "Givonic-bold";
                     position: relative;
                     z-index: -1;
                     opacity: 0.4;
                     /* fill: antiquewhite; */
                     color: red;
                     }

 .colorful-text span {
     -webkit-text-fill-color: #f8f8f8;
     font-size: inherit;
 line-height: inherit;
 letter-spacing: inherit;

 }

 .colorful-text span:nth-child(2) {
     -webkit-text-fill-color: #56f576; /* Green */

 }

 .colorful-text span:nth-child(3) {
     -webkit-text-fill-color: #6e00ca; /* Blue */
 }

 .colorful-text span:nth-child(4) {
     -webkit-text-fill-color: #0c0c13; /* Orange */
 }

 .colorful-text span:nth-child(5) {
     -webkit-text-fill-color: #800080; /* Purple */
 }

 .colorful-text span:nth-child(6) {
     -webkit-text-fill-color: #0c0c13;
 }
 .colorful-text span:nth-child(7) {
     -webkit-text-fill-color: #56f576;
 }
 .colorful-text span:nth-child(8) {
     -webkit-text-fill-color: #56f576;
 } 
 .colorful-text span:nth-child(9) {
     -webkit-text-fill-color: #56f576;;
 }
             </style>
                <h3 class="colorful-text" style="font-size: 221px;">  
                    <span>S</span>
                    <span>E</span>
                    <span>R</span>
                    <span>V</span>
                    <span>I</span>
                    <span>c</span>
                    <span>E</span>
                </h3>
            </div>
        </section>
        <!-- title Banner end -->
       
                <!-- Services start -->
                <section class="services-3 mt-100 container sal-animate" data-sal="slide-up" data-sal-duration="1000" data-sal-delay="500" data-sal-easing="ease-in-out">
                    <div class="row">
                    <!-- @foreach ($data as $index => $datas)
                 <div class="col-lg-{{ $index+1 == 3 ? '12' : '6' }} mb-48 boxx sal-animate" data-sal="slide-up" data-sal-duration="100" data-sal-delay="500" data-sal-easing="ease-in-out">
                            <a href="/service/SEO" class="box" style="justify-content:center">
                                <img src="/images/{{$datas->image_name}}" alt="">
                                <div>
                                <h2 class="fs-40 color-dark-2"> {{ $datas->title_en }} </h2>
                                
                                </div>
                            </a>
                        </div>
                    @endforeach -->
<style>
    /*==================== GOOGLE FONTS ====================*/
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap");

/*==================== VARIABLES CSS ====================*/
:root {
  /*========== Colors ==========*/
  --text-color: #000000;
  --bg-color: #222222;

  /*========== Font and typography ==========*/
  --body-font: "Poppins", sans-serif;
  --normal-font-size: 0.938rem;
}

@media screen and (min-width: 968px) {
  :root {
    --normal-font-size: 1rem;
  }
}

/*==================== SERVICE CARD ====================*/
.card__container {
  display: flex;
  flex-wrap: wrap;
  gap: 60px;
  justify-content: center;
  width: 100%;
  max-width: 90%;
  margin: auto;
  padding: 60px 0;
}
.card__bx {
  --dark-color: #ffffff;
  --dark-alt-color: #777777;
  --white-color: #ffffff;
  --button-color: #333333;
  --transition: 0.5s ease-in-out;

  font-family: inherit;
  height: 350px;
  width: 300px;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  background: var(--dark-color);
  transition: var(--transition);
}
.card__bx::before,
.card__bx::after {
  content: "";
  position: absolute;
  z-index: -1;
  transition: var(--transition);
}
.card__bx::before {
  inset: -10px 50px;
  border-top: 4px solid var(--clr);
  transform: skewY(15deg);
  border-bottom: 4px solid var(--clr);
}
.card__bx:hover::before {
  inset: -10px 40px;
  transform: skewY(0deg);
}
.card__bx::after {
  inset: 60px -10px;
  border-left: 4px solid var(--clr);
  transform: skew(15deg);
  border-right: 4px solid var(--clr);
}
.card__bx:hover::after {
  inset: 40px -10px;
  transform: skew(0deg);
}
.card__bx .card__data {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 30px;
  text-align: center;
  padding: 0 20px;
  height: 100%;
  width: 100%;
  overflow: hidden;
}
.card__bx .card__data .card__icon {
  height: 80px;
  width: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 3rem;
  color: var(--text-color);
  background-color: var(--dark-color);
  transition: var(--transition);
}
.card__bx .card__data .card__icon {
  color: var(--clr);
  box-shadow: 0 0 0 4px var(--dark-color), 0 0 0 6px var(--clr);
}
.card__bx:hover .card__data .card__icon {
  color: var(--dark-color);
  background-color: var(--clr);
  box-shadow: 0 0 0 4px var(--dark-color), 0 0 0 300px var(--clr);
}
.card__bx .card__data .card__content {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 10px;
}
.card__bx .card__data h3 {
  font-size: 1.5rem;
  font-weight: 500;
  color: black;
  transition: var(--transition);
}
.card__bx:hover .card__data h3 {
  color: var(--dark-color);
  transition: var(--transition);
}
.card__bx .card__data p {
  font-size: 0.9rem;
  color: var(--dark-alt-color);
  transition: var(--transition);
}
.card__bx:hover .card__data p {
  color: var(--dark-color);
  transition: var(--transition);
}
.card__bx .card__data a {
  position: relative;
  display: inline-flex;
  padding: 8px 15px;
  text-decoration: none;
  font-weight: 500;
  margin-top: 10px;
  border: 2px solid var(--clr);
  color: var(--dark-color);
  background-color: var(--clr);
  transition: var(--transition);
}
.card__bx:hover .card__data a {
  color: var(--clr);
  background-color: var(--dark-color);
}
.card__bx:hover .card__data a:hover {
  border-color: var(--dark-color);
  color: var(--dark-color);
  background-color: var(--clr);
}

</style> 
<section class="container">
                        
                        
                        <!-- Bottom to top-->
                       
  <section class="card__container">
  @php
$icons = [
    'fa-paintbrush',
    'fa-code',
    // Add 13 more icon classes here
];
$previousColor = null;

@endphp

    @foreach ($data as $index => $datas)
    @php
        $currentColor = $previousColor;
        while ($currentColor === $previousColor) {
            $currentColor = rand(0, 2) == 0 ? '#56f576' : (rand(0, 1) == 1 ? '#56f576' : '#6e00ca');
        }
        $previousColor = $currentColor;
    @endphp
    <div class="card__bx" style="--clr:{{ $currentColor }}">
      <div class="card__data">
        <div class="card__icon">
        <i class="fa-solid  {{ $icons[array_rand($icons)] }}"></i>

        </div>
        <div class="card__content">
          <h3>{{ $datas->title_en }}</h3>
          <p>{{$datas->quotation_en}}</p>
          <a href="/service/{{$datas->id}}">Read More</a>
        </div>
      </div>
    </div>
    <!-- <div class="card__bx" style="--clr: #eb5ae5">
      <div class="card__data">
        <div class="card__icon">
          <i class="fa-solid fa-code"></i>
        </div>
        <div class="card__content">
          <h3>Develoment</h3>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
          <a href="#">Read More</a>
        </div>
      </div>
    </div>
    <div class="card__bx" style="--clr: #5b98eb">
      <div class="card__data">
        <div class="card__icon">
          <i class="fa-brands fa-searchengin"></i>
        </div>
        <div class="card__content">
          <h3>SEO</h3>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
          <a href="#">Read More</a>
        </div>
      </div>
    </div> -->
   @endforeach
  </section>


                  
                        
                        <!-- end Bottom to top-->
 

                 
</section>

                        <!-- <div class="col-lg-6 mb-48 boxx sal-animate" data-sal="slide-down" data-sal-duration="200" data-sal-delay="500" data-sal-easing="ease-in-out">
                            <a href="/service/AEO" class="box">
                                <img src="assets/media/service/4646.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Answer Engine Optimization (AEO) </h2>
                            </a>
                        </div> -->
                        <!-- <div class="col-lg-6 mb-48 boxx sal-animate" data-sal="slide-down" data-sal-duration="200" data-sal-delay="500" data-sal-easing="ease-in-out">
                            <a href="/service/SEM" class="box">
                                <img src="assets/media/service/social_media_performance.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Search Engine Marketing (SEM)</h2>
                            </a>
                        </div>
                        <div class="col-lg-6 mb-48 boxx" style=" ">
                            <a href="/service/Marketing_Strategy" class="box">
                                <img src="assets/media/service/917.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Marketing Startegy</h2>
                            </a>
                        </div>
                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Brand_Identity" class="box">
                                <img src="assets/media/service/2150829239.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Brand Identity</h2>
                            </a>
                        </div>
                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Brand_Strategy" class="box">
                                <img src="assets/media/service/2150829239.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Brand Strategy</h2>
                            </a>
                        </div>
                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Social_Media_Marketing" class="box">
                                <img src="assets/media/service/2150169152.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Social Media Marketing</h2>
                            </a>
                        </div>
                  
                      
                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Influncer_Marketing" class="box">
                                <img src="assets/media/service/influncer.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Influncer Marketing</h2>
                            </a>
                        </div>
                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Media_Buying" class="box">
                                <img src="assets/media/service/influncer.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Digital Media Buying</h2>
                            </a>
                        </div>

                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/OOH" class="box">
                                <img src="assets/media/service/2150866277.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">OOH &amp; ProdCast</h2>
                            </a>
                        </div>

                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Website" class="box">
                                <img src="assets/media/service/2150866277.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Website Design &amp; Development</h2>
                            </a>
                        </div>
                        <div class="col-lg-6 mb-48 boxx">
                            <a href="/service/Mobile_App" class="box">
                                <img src="assets/media/service/mobile_dev.jpg" alt="">
                                <h2 class="fs-40 color-dark-2">Mobile Application Development</h2>
                            </a>
                        </div> -->
                    </div>
                </section>
              

 @endsection
 <style lang="scss">


                    .box{
                        display: flex !important;
                        flex-direction: row;
                        gap: 2em;
                       
                    }
                    .box img{
                            width: 300px !important;
                            height:350px;
                            border-top-left-radius: 20px;
                            border-bottom-left-radius: 20px;
                        }
                        .boxx{
                            background-color:transparent,  right;
                                background-size: 200%;
                                transition: .5s ease-out;
                        }
                        .boxx:hover{
                            background-position: left;
                            box-shadow: -9px 3px 19px 4px #888888;
                            border-top-left-radius: 20px;
                            border-bottom-left-radius: 20px;
                            padding-left: 0px !important;
                            border-radius: 30px;
                        }
                       
                </style>
    
